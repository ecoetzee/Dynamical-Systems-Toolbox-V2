%parameters(1)=a;
parameters(1)=0.1;

%parameters(2)=e;
parameters(2)= 0.12;

%parameters(3)=Iz;
parameters(3)=1.0;

%parameters(4)=Fz;
parameters(4)=5.49853E+04;

%parameters(5)=c;
parameters(5)=-100000.0;

%parameters(6)=cFa;
parameters(6)=20;

%parameters(7)=cMa;
parameters(7)=-2;

%parameters(8)=k;
parameters(8)=-45.0;

%parameters(9)=kappa;
parameters(9)=-270;

%parameters(10)=sigma;
parameters(10)=0.3;

%parameters(11)=alphag;
parameters(11)=10*pi/180;

%parameters(12)=delta;
parameters(12)=5*pi/180;

%parameters(13)=V;
parameters(13)=205;

%parameters(14)=ksdelta;
parameters(14)=-3.35343E+07;

%parameters(15)=csdelta;
parameters(15)=-150.0;